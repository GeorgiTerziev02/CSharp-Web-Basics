﻿namespace SharedTrip.ViewModels
{
    public class LoginInputViewModel
    {
        public string Username { get; set; }

        public string Password { get; set; }
    }
}
